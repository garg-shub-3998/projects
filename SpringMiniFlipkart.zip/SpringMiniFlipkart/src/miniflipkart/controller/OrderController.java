
package miniflipkart.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import miniflipkart.entity.Order;
import miniflipkart.entity.OrderItems;
import miniflipkart.service.OrderService;

/**
 * @author Shubham Garg
 *
 */
@Controller
@RequestMapping("/order")
public class OrderController {

	@Autowired
	private OrderService orderService;

	@GetMapping("/list")
	public String orderList(Model model,HttpServletRequest request) {
		// get customer id from session
		int customerid = (int) request.getSession().getAttribute("userid");
		
		// get order
		List<Order> orders = orderService.getOrders(customerid);
		
		// add to model
		model.addAttribute("orders", orders);
		
		return "order";
	}

	@GetMapping("/orderItems")
	public String orderItems(@RequestParam("orderid") int id,Model model) {
		
		// get order items
		List<OrderItems> oi = orderService.getOrderItems(id);
		
		// add to model
		model.addAttribute("items", oi);
		
		return "list-order";
	}
}
