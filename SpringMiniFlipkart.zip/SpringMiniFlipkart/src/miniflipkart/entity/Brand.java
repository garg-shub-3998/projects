
package miniflipkart.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

/**
 * @author Shubham Garg
 *
 */
@Entity
@Table(name = "brand")
public class Brand {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "name")
	private String name;

	@CreationTimestamp
	@Column(name = "createdat")
	private java.sql.Timestamp createdAt;

	@UpdateTimestamp
	@Column(name = "updatedat")
	private java.sql.Timestamp updatedAt;

	// ----------------------------------------- Constructor
	// -----------------------------------------

	/**
	 * No-Argument Conostructor
	 */
	public Brand() {

	}

	/**
	 * Parameterized Constructor
	 * 
	 * @param name
	 */
	public Brand(String name) {
		this.name = name;
	}

	// -----------------------------------
	// getters/setters------------------------------

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the createdAt
	 */
	public java.sql.Timestamp getCreatedAt() {
		return createdAt;
	}

	/**
	 * @return the updatedAt
	 */
	public java.sql.Timestamp getUpdatedAt() {
		return updatedAt;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(java.sql.Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @param updatedAt the updatedAt to set
	 */
	public void setUpdatedAt(java.sql.Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	@Override
	public String toString() {
		return String.format("Brand [id=%s, name=%s, createdAt=%s, updatedAt=%s]", id, name, createdAt, updatedAt);
	}

}
