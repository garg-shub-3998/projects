
package miniflipkart.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import miniflipkart.service.UserService;
import miniflipkart.validator.Validator;

/**
 * @author Shubham Garg
 *
 */
@Controller
@RequestMapping("/login")
public class LoginController {

	/**
	 * Validator Object
	 */
	@Autowired
	private Validator validator;

	/**
	 * User Service Object
	 */
	@Autowired
	private UserService userService;

	/**
	 * display login form
	 * 
	 * @return login-form
	 */
	@GetMapping("/showForm")
	public String showHome() {
		return "login-form";
	}

	/**
	 * authenticate the user
	 * 
	 * @param request
	 * @param response
	 * @return login-form / showProducts / showBrands
	 * @throws Exception
	 */
	@PostMapping("/validate")
	public String validateLogin(HttpServletRequest request, HttpServletResponse response) throws Exception {

		// extract user name and password
		String username = request.getParameter("name");
		String password = request.getParameter("password");

		// authentiacte the user credentials
		boolean ans = validator.validateLogin(username, password);
		if (ans) {
			// loging in if user authentication passed
			System.out.println("login successfull");

			// extract usertype and userid
			String type = userService.getUserType(username, password);
			int id = userService.getUserId(username, password);

			// set user type and id into session
			request.getSession().setAttribute("usertype", type);
			request.getSession().setAttribute("userid", id);

			// calling particular controller based on user type
			if (type.equals("customer")) {
				response.sendRedirect("/SpringMiniFlipkart/customer/showProducts");
			} else if (type.equals("vendor")) {
				response.sendRedirect("/SpringMiniFlipkart/vendor/showProducts");
			} else {
				response.sendRedirect("/SpringMiniFlipkart/admin/showBrands");
			}
		} else {

			// throwing error if user cuthentication fails
			request.setAttribute("errorMessage", "Invalid Username or Password");
			return "login-form";
		}

		return null;
	}

}
