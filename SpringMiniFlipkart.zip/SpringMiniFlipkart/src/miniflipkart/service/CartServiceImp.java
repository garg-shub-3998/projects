
package miniflipkart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import miniflipkart.dao.CartDao;
import miniflipkart.dao.OrderDao;
import miniflipkart.dao.ProductDao;
import miniflipkart.dao.UserDao;
import miniflipkart.entity.Cart;
import miniflipkart.entity.CartItems;
import miniflipkart.entity.Order;
import miniflipkart.entity.Product;
import miniflipkart.entity.User;

/**
 * @author Shubham Garg
 *
 */
@Service
public class CartServiceImp implements CartService {
	
    /**
     * Cart Dao object
     */
	@Autowired
	private CartDao cartdao;
	
	/**
     * Product Dao object
     */
	@Autowired
	private ProductDao productdao;

	/**
     * Order Dao object
     */
	@Autowired
	private OrderDao orderdao;

	/**
     * User Dao object
     */
	@Autowired
	private UserDao userdao;

	/**
	 * @return number of intems in the cart
	 */
	@Override
	@Transactional
	public int getCartCount(int customerid) {
		// get cart
		Cart cart = cartdao.getCart(customerid);

		return cart.getNumberOfItems();
	}

	/**
	 * adds new product to the cart
	 */
	@Override
	@Transactional
	public void addNewProduct(int pid, int customerid) {

		// get cart
		Cart cart = cartdao.getCart(customerid);

		// get product
		Product product = productdao.getProduct(pid);

		// check if cart contains product
		CartItems ci = cartdao.getCartItem(cart, product);
		if (ci != null) {
			// udate cart and cart item
			cart.setAmount(cart.getAmount() + ci.getUnitPrice());
			ci.setQuantity(ci.getQuantity() + 1);
			ci.setTotalPrice(ci.getTotalPrice() + ci.getUnitPrice());

			// save cart and cartitem
			cartdao.saveCart(cart);
			cartdao.saveCartItem(ci);

		} else {
			// add to cart items
			cartdao.addNewCartItem(product, cart);

			// update cart
			cart.setAmount(cart.getAmount() + product.getPrice());
			cart.setNumberOfItems(cart.getNumberOfItems() + 1);
			cartdao.saveCart(cart);
		}
	}

	/**
	 * @return list of items in the cart
	 */
	@Override
	@Transactional
	public List<CartItems> getCartItems(int customerid) {
		// get cart
		Cart cart = cartdao.getCart(customerid);

		// get cart items
		List<CartItems> cartitems = cartdao.getCartItems(cart.getId());

		return cartitems;
	}

	/**
	 * delete the cart item from cart
	 */
	@Override
	@Transactional
	public void deleteItem(int id) {
		// get cart item
		CartItems ci = cartdao.getCartItem(id);

		// get cart
		Cart c = cartdao.getCart(ci.getCart().getUser().getId());

		// update cart
		c.setNumberOfItems(c.getNumberOfItems() - 1);
		c.setAmount(c.getAmount() - ci.getTotalPrice());
		cartdao.saveCart(c);

		// delete cart item
		cartdao.deleteCartItem(ci);
	}

	/**
	 * decrease the quantity of item in the cart
	 */
	@Override
	@Transactional
	public void deleteFromItem(int id) {
		// get cart item
		CartItems ci = cartdao.getCartItem(id);

		// get cart
		Cart c = cartdao.getCart(ci.getCart().getUser().getId());

		if (ci.getQuantity() > 1) {
			// udate cart and cart item
			c.setAmount(c.getAmount() - ci.getUnitPrice());
			ci.setQuantity(ci.getQuantity() - 1);
			ci.setTotalPrice(ci.getTotalPrice() - ci.getUnitPrice());

			// save cart and cartitem
			cartdao.saveCart(c);
			cartdao.saveCartItem(ci);

		} else {
			// update cart
			c.setNumberOfItems(c.getNumberOfItems() - 1);
			c.setAmount(c.getAmount() - ci.getTotalPrice());
			cartdao.saveCart(c);

			// delete cart item
			cartdao.deleteCartItem(ci);
		}

	}

	/**
	 * increase the quantity of item in the cart
	 */
	@Override
	@Transactional
	public void addToItem(int id) {
		// get cart item
		CartItems ci = cartdao.getCartItem(id);

		// get cart
		Cart c = cartdao.getCart(ci.getCart().getUser().getId());

		// udate cart and cart item
		c.setAmount(c.getAmount() + ci.getUnitPrice());
		ci.setQuantity(ci.getQuantity() + 1);
		ci.setTotalPrice(ci.getTotalPrice() + ci.getUnitPrice());

		// save cart and cartitem
		cartdao.saveCart(c);
		cartdao.saveCartItem(ci);
	}

	/**
	 * performs checkout
	 */
	@Override
	@Transactional
	public void saveOrder(String ptype, int customerid) {
		// get cart
		Cart c = cartdao.getCart(customerid);

		// get customer
		User customer = userdao.getUserById(customerid);

		Order order = new Order(customer, c.getAmount(), ptype);

		// save order
		orderdao.saveOrder(order);
	}

	/**
	 * performs checkout
	 */
	@Override
	@Transactional
	public void saveOrderItems(int customerid) {
		// get order
		Order order = orderdao.getOrder(customerid);

		// get cart
		Cart c = cartdao.getCart(customerid);
		
		// get list of cart items
		List<CartItems> ci = cartdao.getCartItems(c.getId());
		
		// save order items
		orderdao.saveOrderItems(ci, order);
		
		// delete cartitems
		
		for(int i = 0; i < ci.size(); i++) {
			c.setAmount(c.getAmount() - ci.get(i).getTotalPrice());
			c.setNumberOfItems(c.getNumberOfItems() - 1);
			cartdao.saveCart(c);
			cartdao.deleteCartItem(ci.get(i));
		}
	}

}
