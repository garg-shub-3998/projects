
package miniflipkart.dao;

import java.util.List;

import miniflipkart.entity.Brand;

/**
 * @author  Shubham Garg
 *
 */

public interface BrandDao {

	
	public List<Brand> getBrandList();

	
	public void save(Brand brand);

	
	public void delete(Brand brand);

	public Brand getBrand(int id);


}
