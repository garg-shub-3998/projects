
package miniflipkart.validator;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import miniflipkart.dao.BrandDao;
import miniflipkart.dao.CartDao;
import miniflipkart.dao.OrderDao;
import miniflipkart.dao.ProductDao;
import miniflipkart.dao.UserDao;
import miniflipkart.entity.Brand;
import miniflipkart.entity.CartItems;
import miniflipkart.entity.OrderItems;
import miniflipkart.entity.Product;
import miniflipkart.entity.User;

/**
 * @author Shubham Garg
 *
 */
@Service
public class ValidatorImp implements Validator {

	/**
	 * User Dao object
	 */
	@Autowired
	private UserDao userdao;

	/**
	 * Brand Dao Object
	 */
	@Autowired
	private BrandDao branddao;

	/**
	 * Product Dao Object
	 */
	@Autowired
	private ProductDao productdao;

	/**
	 * Cart Dao object
	 */
	@Autowired
	private CartDao cartdao;

	/**
	 * Order Dao object
	 */
	@Autowired
	private OrderDao orderdao;

	/**
	 * Validates if user is authorized or not
	 */
	@Override
	@Transactional
	public boolean validateLogin(String name, String password) {

		// extract user from database based on username and password
		User user = userdao.getUser(name, password);

		if (user != null)
			return true;
		else
			return false;

	}

	/**
	 * Validated username for new user
	 */
	@Override
	@Transactional
	public boolean validateUsername(String userName) {
		boolean ans = false;
		User user = userdao.getUserByUsername(userName);
		if (user == null)
			ans = true;
		return ans;
	}

	/**
	 * Validated email for new user
	 */
	@Override
	@Transactional
	public boolean validateEmail(String email) {
		boolean ans = false;
		User user = userdao.getUserByEmail(email);
		if (user == null)
			ans = true;
		return ans;
	}

	/**
	 * Validated phonenumber for new user
	 */
	@Override
	@Transactional
	public boolean validatePhonenumber(String phoneNumber) {
		boolean ans = false;
		User user = userdao.getUserByPhoneNumber(phoneNumber);
		if (user == null)
			ans = true;
		return ans;
	}

	/**
	 * validate is brand already exist or not
	 */
	@Override
	@Transactional
	public boolean validateBrand(Brand brand) {
		boolean ans = true;

		// extract list of brands from database
		List<Brand> b = branddao.getBrandList();

		// conpares name of brands
		for (int i = 0; i < b.size(); i++) {
			if (brand.getName().toLowerCase().equals(b.get(i).getName().toLowerCase())) {
				ans = false;
				break;
			}
		}
		return ans;
	}

	/**
	 * validate is product already exist or not
	 */
	@Override
	@Transactional
	public boolean validateProduct(Product product, int vendorid) {

		boolean ans = true;

		// extract list of products from database
		List<Product> p = productdao.getProducts(vendorid);

		// conpares name of products
		for (int i = 0; i < p.size(); i++) {
			if (product.getName().toLowerCase().equals(p.get(i).getName().toLowerCase())) {
				ans = false;
				break;
			}
		}
		return ans;
	}

	/**
	 * Validate product for deletion
	 */
	@Override
	@Transactional
	public boolean validateProductDelete(int id) {
		CartItems ci = cartdao.getCartItemByProductId(id);
		OrderItems o = orderdao.getOrderItemByProductId(id);
		if (ci == null && o == null)
			return true;
		else
			return false;
	}

	/**
	 * Validate brand for deletion
	 */
	@Override
	@Transactional
	public boolean validateBrandDelete(int id) {
		List<Product> p = productdao.getProductByBrandId(id);
		if (p == null)
			return true;
		else
			return false;
	}

}
