
package miniflipkart.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import miniflipkart.dao.AddressDao;
import miniflipkart.dao.CartDao;
import miniflipkart.dao.CustomerAddressDao;
import miniflipkart.dao.UserDao;
import miniflipkart.dao.VendorAddressDao;
import miniflipkart.entity.Address;
import miniflipkart.entity.User;

/**
 * @author Shubham Garg
 *
 */
@Service
public class UserServiceImp implements UserService {

	/**
	 * User Dao Object
	 */
	@Autowired
	private UserDao userdao;

	/**
	 * Address Dao Object
	 */
	@Autowired
	private AddressDao addressdao;

	/**
	 * CustomerAddress Dao Object
	 */
	@Autowired
	private CustomerAddressDao customeraddressdao;

	/**
	 * Vendor Dao Object
	 */
	@Autowired
	private VendorAddressDao vendoraddressdao;

	/**
	 * Cart Dao Object
	 */
	@Autowired
	private CartDao cartdao;

	/**
	 * Saves a new user
	 */
	@Override
	@Transactional
	public void saveUser(User user, Address address) {
		// save user
		userdao.saveUser(user);

		// Save address
		addressdao.saveAddress(address);

		// saving user address relation
		if (user.getUserType().equals("customer")) {
			customeraddressdao.save(user, address);
			cartdao.generateCart(user);
		} else {
			vendoraddressdao.save(user, address);
		}
	}

	/**
	 * Get the user type
	 */
	@Override
	@Transactional
	public String getUserType(String username, String password) {

		String type = "customer";

		// extract user from database
		User user = userdao.getUser(username, password);

		type = user.getUserType();

		return type;
	}

	/**
	 * Get user Id
	 */
	@Override
	@Transactional
	public int getUserId(String username, String password) {
		int id = 0;

		// extract user from database
		User user = userdao.getUser(username, password);

		id = user.getId();

		return id;
	}

	/**
	 * get vendor by id
	 */
	@Override
	@Transactional
	public User getUser(int vendorid) {

		// extract user by id
		return userdao.getUserById(vendorid);
	}

}
