/**
 * 
 */
package miniflipkart.dao;

import miniflipkart.entity.User;

/**
 * UserDao interface
 * 
 * @author  Shubham Garg
 *
 */
public interface UserDao {

	public User getUser(String username, String password);

	
	public User getUserByUsername(String userName);

	
	public User getUserByEmail(String email);


	public User getUserByPhoneNumber(String phoneNumber);

	
	public void saveUser(User user);


	
	public User getUserById(int vendorid);
}
