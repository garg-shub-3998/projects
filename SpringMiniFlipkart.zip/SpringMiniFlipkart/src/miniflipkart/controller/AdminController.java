
package miniflipkart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import miniflipkart.entity.Brand;
import miniflipkart.service.BrandService;
import miniflipkart.validator.Validator;

/**
 * @author Shubham Garg
 *
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

	/**
	 * brandService object
	 */
	@Autowired
	private BrandService brandService;

	/**
	 * Validator object
	 */
	@Autowired
	private Validator validator;

	/**
	 * show the list of brands availabe
	 * 
	 * @param model
	 * @return brand-list.jsp page
	 */
	@GetMapping("/showBrands")
	public String showBrands(Model model) {
		// get brands from database
		List<Brand> brands = brandService.getBrands();

		// add brand to model
		model.addAttribute("brands", brands);

		return "brand-list";

	}

	/**
	 * shows the add brand page
	 * 
	 * @return add-brand.jsp
	 */
	@GetMapping("/addBrandForm")
	public String addBrandForm() {

		return "add-brand";

	}

	/**
	 * add new brand to database
	 * 
	 * @param brand
	 * @param model
	 * @return showBrands or add-brand
	 */
	@PostMapping("addBrand")
	public String addBrand(@ModelAttribute Brand brand, Model model) {

		boolean ans = validator.validateBrand(brand);
		if (ans) {
			brandService.save(brand);
			return "redirect:/admin/showBrands";
		} else {
			model.addAttribute("errorMessage", "Brand already exist");
			model.addAttribute("brand", brand);
			return "add-brand";
		}

	}

	/**
	 * delete brand from database
	 * 
	 * @param id
	 * @return showBrands
	 */
	@GetMapping("/deleteBrand")
	public String deleteBrand(@RequestParam("brandid") int id, Model model) {
		System.out.println(id);
		if (validator.validateBrandDelete(id))
			brandService.delete(id);
		else
			model.addAttribute("errorMessage","Brand Cannot be deleted");
		
		return "redirect:/admin/showBrands";

	}
}
