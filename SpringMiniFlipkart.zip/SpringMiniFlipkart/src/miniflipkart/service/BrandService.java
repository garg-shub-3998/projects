
package miniflipkart.service;

import java.util.List;

import miniflipkart.entity.Brand;

/**
 * @author  Shubham Garg
 *
 */
public interface BrandService {

	
	public List<Brand> getBrands();

	public void save(Brand brand);

	public void delete(int id);

	public Brand getBrand(int bid);

}
