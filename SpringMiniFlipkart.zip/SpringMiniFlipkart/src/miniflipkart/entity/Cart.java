
package miniflipkart.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

/**
 * Entity class Cart
 * 
 * @author  Shubham Garg
 *
 */
@Entity
@Table(name="cart")
public class Cart {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@OneToOne
	@JoinColumn(name="customerid")
	private User user;
	
	@Column(name="amount")
	private int amount;
	
	@Column(name="numberofitems")
	private int numberOfItems;
	
	@CreationTimestamp
	@Column(name="createdat")
	private java.sql.Timestamp createdAt;
	
	@UpdateTimestamp
	@Column(name="updatedat")
	private java.sql.Timestamp updatedAt;
	
	
	
	// --------------------------------- Constructor
	//------------------------------------------------

	// No Argument Constructor
	public Cart() {
		
	}

	// Parameterized Constructor
	/**
	 * @param amount
	 * @param numberOfItems
	 */
	public Cart(int amount, int numberOfItems, User user) {
		this.amount = amount;
		this.numberOfItems = numberOfItems;
		this.user = user;
	}

	
	// ----------------------------------Getters/Setters
	//----------------------------------------------------
	
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @return the amount
	 */
	public int getAmount() {
		return amount;
	}

	/**
	 * @return the numberOfItems
	 */
	public int getNumberOfItems() {
		return numberOfItems;
	}

	/**
	 * @return the createdAt
	 */
	public java.sql.Timestamp getCreatedAt() {
		return createdAt;
	}

	/**
	 * @return the updatedAt
	 */
	public java.sql.Timestamp getUpdatedAt() {
		return updatedAt;
	}

	/**
	 * @param set the id 
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @param set the user 
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * @param set the amount 
	 */
	public void setAmount(int amount) {
		this.amount = amount;
	}

	/**
	 * @param set the numberOfItems 
	 */
	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}

	/**
	 * @param set the createdAt 
	 */
	public void setCreatedAt(java.sql.Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @param set the updatedAt 
	 */
	public void setUpdatedAt(java.sql.Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	

	@Override
	public String toString() {
		return String.format("Cart [id=%s, user=%s, amount=%s, numberOfItems=%s, createdAt=%s, updatedAt=%s]", id, user,
				amount, numberOfItems, createdAt, updatedAt);
	}
	
	
	
}
