
package miniflipkart.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

/**
 * Entity class User that contains admin, customer and vendor
 * 
 * @author Shubham Garg
 *
 */
@Entity
@Table(name = "user")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "firstname")
	private String firstName;

	@Column(name = "lastname")
	private String lastName;

	@Column(name = "username")
	private String userName;

	@Column(name = "age")
	private int age;

	@Column(name = "phonenumber")
	private String phoneNumber;

	@Column(name = "email")
	private String email;

	@Column(name = "usertype")
	private String userType;

	@CreationTimestamp
	@Column(name = "createdat")
	private java.sql.Timestamp createdAt;

	@UpdateTimestamp
	@Column(name = "updatedat")
	private java.sql.Timestamp updatedAt;

	@Column(name = "password")
	private String password;

	@Column(name = "gender")
	private String gender;

	// Constructor

	/**
	 * No-Argument Constructor
	 */
	public User() {

	}

	/**
	 * Parameterized Construcotr
	 * 
	 * @param firstName
	 * @param lastName
	 * @param userName
	 * @param age
	 * @param phoneNumber
	 * @param email
	 * @param userType
	 * @param createdAt
	 * @param updatedAt
	 * @param password
	 * @param gender
	 * @param address
	 */
	public User(String firstName, String lastName, String userName, int age, String phoneNumber, String email,
			String userType, String password, String gender) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.userName = userName;
		this.age = age;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.userType = userType;
		this.password = password;
		this.gender = gender;
	}

	// Getters/Setters

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @return the userType
	 */
	public String getUserType() {
		return userType;
	}

	/**
	 * @return the createdAt
	 */
	public java.sql.Timestamp getCreatedAt() {
		return createdAt;
	}

	/**
	 * @return the updatedAt
	 */
	public java.sql.Timestamp getUpdatedAt() {
		return updatedAt;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param set the id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @param set the firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @param set the lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @param set the userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @param set the age
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * @param set the phoneNumber
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @param set the email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @param set the userType
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}

	/**
	 * @param set the createdAt
	 */
	public void setCreatedAt(java.sql.Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @param set the updatedAt
	 */
	public void setUpdatedAt(java.sql.Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	/**
	 * @param set the password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @param set the gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return String.format(
				"User [id=%s, firstName=%s, lastName=%s, userName=%s, age=%s, phoneNumber=%s, email=%s, userType=%s, createdAt=%s, updatedAt=%s, password=%s, gender=%s]",
				id, firstName, lastName, userName, age, phoneNumber, email, userType, createdAt, updatedAt, password,
				gender);
	}

}
