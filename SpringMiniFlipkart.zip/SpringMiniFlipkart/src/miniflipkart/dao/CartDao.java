
package miniflipkart.dao;

import java.util.List;

import miniflipkart.entity.Cart;
import miniflipkart.entity.CartItems;
import miniflipkart.entity.Product;
import miniflipkart.entity.User;

/**
 * @author  Shubham Garg
 *
 */
public interface CartDao {

	
	public void generateCart(User user);

	
	public Cart getCart(int customerid);

	
	public List<CartItems> getCartItems(int cartid);


	public void addNewCartItem(Product product, Cart cart);

	
	public void saveCart(Cart cart);


	public CartItems getCartItem(int id);


	public void deleteCartItem(CartItems ci);


	public void saveCartItem(CartItems ci);


	public CartItems getCartItem(Cart cart, Product product);

	
	public CartItems getCartItemByProductId(int id);

}
