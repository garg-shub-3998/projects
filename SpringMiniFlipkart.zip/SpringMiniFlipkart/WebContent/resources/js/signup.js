function validate(form) {

		var usertype = form.userType.value;
		var username = form.userName.value;
		var email = form.email.value;
		var phonenumber = form.phoneNumber.value;
		var password = form.password.value;
		var cpassword = form.cpassword.value;
		var firstname = form.firstName.value;
		var lastname = form.lastName.value;
		var housenumber = form.houseNumber.value;
		var locality = form.locality.value;
		var state = form.state.value;
		var country = form.country.value;
		var pincode = form.pincode.value;

		document.getElementById('usertype').innerHTML = "";
		if (usertype == "") {
			document.getElementById('usertype').innerHTML = "Please fill this field";
			alert();
			return false;
		}
		document.getElementById('username').innerHTML = "";
		if (username == "") {
			document.getElementById('username').innerHTML = "Please fill this field";
			return false;
		}
		document.getElementById('email').innerHTML = "";
		if (email == "") {
			document.getElementById('email').innerHTML = "Please fill this field";
			return false;
		}
		document.getElementById('phonenumber').innerHTML = "";
		if (phonenumber == "") {
			document.getElementById('phonenumber').innerHTML = "Please fill this field";
			return false;
		}
		if (phonenumber.length != 10) {
			document.getElementById('phonenumber').innerHTML = "Invalid phone number";
			return false;
		}
		document.getElementById('password').innerHTML = "";
		document.getElementById('cpassword').innerHTML = "";
		if (password == "") {
			document.getElementById('password').innerHTML = "Please fill this field";
			return false;
		}
		if (cpassword == "") {
			document.getElementById('cpassword').innerHTML = "Please fill this field";
			return false;
		}
		if (password != cpassword) {
			document.getElementById('cpassword').innerHTML = "Passowrd did not match";
			return false;
		}
		document.getElementById('firstname').innerHTML = "";
		if (firstname == "") {
			document.getElementById('firstname').innerHTML = "Please fill this field";
			return false;
		}
		document.getElementById('lastname').innerHTML = "";
		if (lastname == "") {
			document.getElementById('lastname').innerHTML = "Please fill this field";
			return false;
		}
		document.getElementById('housenumber').innerHTML = "";
		if (housenumber == "") {
			document.getElementById('housenumber').innerHTML = "Please fill this field";
			return false;
		}
		if (housenumber.length > 20) {
			document.getElementById('housenumber').innerHTML = "Maximum characters can be 20 only";
			return false;
		}
		document.getElementById('locality').innerHTML = "";
		if (locality == "") {
			document.getElementById('locality').innerHTML = "Please fill this field";
			return false;
		}
		document.getElementById('state').innerHTML = "";
		if (state == "") {
			document.getElementById('state').innerHTML = "Please fill this field";
			return false;
		}
		document.getElementById('country').innerHTML = "";
		if (country == "") {
			document.getElementById('country').innerHTML = "Please fill this field";
			return false;
		}
		document.getElementById('pincode').innerHTML = "";
		if (pincode == "") {
			document.getElementById('pincode').innerHTML = "Please fill this field";
			return false;
		}

	}