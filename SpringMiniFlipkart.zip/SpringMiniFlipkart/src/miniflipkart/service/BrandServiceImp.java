/**
 * 
 */
package miniflipkart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import miniflipkart.dao.BrandDao;
import miniflipkart.entity.Brand;

/**
 * @author Shubham Garg
 *
 */
@Service
public class BrandServiceImp implements BrandService {
	/**
	 * Brand Dao Object
	 */
	@Autowired
	private BrandDao brandDao;

	/**
	 * Generate the list of available brands
	 */
	@Override
	@Transactional
	public List<Brand> getBrands() {

		// gives the list of brands
		return brandDao.getBrandList();
	}

	/**
	 * Saves a new Brand
	 */
	@Override
	@Transactional
	public void save(Brand brand) {

		// save new brand
		brandDao.save(brand);

	}

	/**
	 * Delete a brand
	 */
	@Override
	@Transactional
	public void delete(int id) {

		// extract brand
		Brand brand = brandDao.getBrand(id);
		System.out.println(brand);

		// delete brand
		brandDao.delete(brand);
	}

	/**
	 * Get a brand by id
	 */
	@Override
	@Transactional
	public Brand getBrand(int bid) {

		// gives brand by id
		return brandDao.getBrand(bid);
	}

}
