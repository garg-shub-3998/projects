
package miniflipkart.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import miniflipkart.entity.CartItems;
import miniflipkart.service.CartService;

/**
 * @author Shubham Garg
 *
 */
@Controller
@RequestMapping("/cart")
public class CartController {

	@Autowired
	private CartService cartService;

	@GetMapping("/showCart")
	public String showCart(Model model, HttpServletRequest request) {
		// get customer id from session
		int customerid = (int) request.getSession().getAttribute("userid");

		// extract list of cart items
		List<CartItems> items = cartService.getCartItems(customerid);

		int carttotal = 0;
		for (int i = 0; i < items.size(); i++) {
			carttotal += items.get(i).getTotalPrice();
		}

		// Add items to model
		model.addAttribute("items", items);
		model.addAttribute("carttotal", carttotal);

		return "cart";
	}

	@GetMapping("/deleteCartItem")
	public String deleteCartItem(@RequestParam("itemid") int id) {
		cartService.deleteItem(id);
		return "redirect:showCart";
	}

	@GetMapping("/deleteFromCartItem")
	public String deleteFromCartItem(@RequestParam("itemid") int id) {
		cartService.deleteFromItem(id);
		return "redirect:showCart";
	}

	@GetMapping("/addToCartItem")
	public String addToCartItem(@RequestParam("itemid") int id) {
		cartService.addToItem(id);
		return "redirect:showCart";
	}

	@GetMapping("/checkout")
	public String checkout(@RequestParam("amount") int amount, Model model) {
		model.addAttribute("amount", amount);
		return "checkout";
	}

	@PostMapping("/performCheckout")
	public String checkout(@RequestParam("ptype") String ptype,HttpServletRequest request) {
		// get customer id from session
		int customerid = (int) request.getSession().getAttribute("userid");

		cartService.saveOrder(ptype,customerid);
		cartService.saveOrderItems(customerid);

		return "redirect:/customer/showProducts";
	}

}
