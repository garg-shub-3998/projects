
package miniflipkart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import miniflipkart.dao.OrderDao;
import miniflipkart.entity.Order;
import miniflipkart.entity.OrderItems;

/**
 * @author  Shubham Garg
 *
 */
@Service
public class OrderServiceImp implements OrderService {
	
	/**
	 * Order Dao object
	 */
	@Autowired
	private OrderDao orderdao;

	/**
	 * @return list of orders by customer
	 */
	@Override
	@Transactional
	public List<Order> getOrders(int customerid) {
		List<Order> orders = orderdao.getOrders(customerid);
		return orders;
	}

	/**
	 * @return list of order items in each order
	 */
	@Override
	@Transactional
	public List<OrderItems> getOrderItems(int id) {
		return orderdao.getOrderItems(id);
	}

}
