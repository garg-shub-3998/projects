
package miniflipkart.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import miniflipkart.entity.Cart;
import miniflipkart.entity.CartItems;
import miniflipkart.entity.Order;
import miniflipkart.entity.OrderItems;
import miniflipkart.entity.User;

/**
 * @author Shubham Garg
 *
 */
@Repository
public class OrderDaoImp implements OrderDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void saveOrderItems(List<CartItems> ci, Order order) {

		// generate session
		Session session = sessionFactory.getCurrentSession();

		for (int i = 0; i < ci.size(); i++) {
			OrderItems oi = new OrderItems(order, ci.get(i).getProduct(), ci.get(i).getQuantity(),
					ci.get(i).getUnitPrice(), ci.get(i).getTotalPrice());
			session.save(oi);
		}
	}

	@Override
	public void saveOrder(Order order) {

		// generate session
		Session session = sessionFactory.getCurrentSession();

		// save order
		session.saveOrUpdate(order);

	}

	@Override
	public Order getOrder(int customerid) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// query
		Query query = session.createQuery("from Order where customerid = ?0 order by id");
		query.setParameter(0, customerid);

		List<Order> orders = null;
		try {
			orders = query.getResultList();
		} catch (Exception e) {
			System.out.println(e);
		}

		return orders.get(orders.size() - 1);
	}

	@Override
	public List<Order> getOrders(int customerid) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// query
		Query query = session.createQuery("from Order where customerid = ?0");
		query.setParameter(0, customerid);

		List<Order> orders = null;
		try {
			orders = query.getResultList();
		} catch (Exception e) {
			System.out.println(e);
		}
		return orders;
	}

	@Override
	public List<OrderItems> getOrderItems(int id) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// query
		Query query = session.createQuery("from OrderItems where orderid = ?0 ");
		query.setParameter(0, id);

		List<OrderItems> oi = null;
		try {
			oi = query.getResultList();
		} catch (Exception e) {
			System.out.println(e);
		}
		return oi;
	}

	@Override
	public OrderItems getOrderItemByProductId(int id) {
		// create session
		Session session = sessionFactory.getCurrentSession();

		// get cartitems list
		Query query = session.createQuery("from OrderItems where productid = ?0");
		query.setParameter(0, id);

		List<OrderItems> oi = null;

		try {
			oi = query.getResultList();
		} catch (Exception e) {
			System.out.println(e);
		}

		if(oi.size() == 0) return null;
		else return oi.get(0);
	}

}
