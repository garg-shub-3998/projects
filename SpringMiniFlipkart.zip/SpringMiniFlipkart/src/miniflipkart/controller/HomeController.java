/**
 * 
 */
package miniflipkart.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author Shubham Garg
 *
 */
@Controller
public class HomeController {

	/**
	 * Display HomePage of application
	 * 
	 * @return home
	 */
	@RequestMapping("/home")
	public String showHome() {
		return "home";
	}
}
