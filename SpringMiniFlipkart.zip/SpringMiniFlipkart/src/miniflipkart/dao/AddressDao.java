
package miniflipkart.dao;

import miniflipkart.entity.Address;

/**
 * @author  Shubham Garg
 *
 */
public interface AddressDao {

	
	public void saveAddress(Address address);

}
