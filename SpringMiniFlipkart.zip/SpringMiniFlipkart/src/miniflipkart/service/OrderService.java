
package miniflipkart.service;

import java.util.List;

import miniflipkart.entity.Order;
import miniflipkart.entity.OrderItems;

/**
 * @author  Shubham Garg
 *
 */
public interface OrderService {

	
	List<Order> getOrders(int customerid);

	
	List<OrderItems> getOrderItems(int id);

}
