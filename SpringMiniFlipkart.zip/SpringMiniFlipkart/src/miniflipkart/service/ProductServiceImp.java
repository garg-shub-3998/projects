
package miniflipkart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import miniflipkart.dao.ProductDao;
import miniflipkart.entity.Product;

/**
 * @author Shubham Garg
 *
 */
@Service
public class ProductServiceImp implements ProductService {

	/**
	 * Product Dao Object
	 */
	@Autowired
	private ProductDao productdao;

	/**
	 * Get the list of products of a particular vendor
	 */
	@Override
	@Transactional
	public List<Product> getProducts(int vendorid) {

		// return list of product by each vendor
		return productdao.getProducts(vendorid);
	}

	/**
	 * Saves a new product
	 */
	@Override
	@Transactional
	public void save(Product product) {

		// save a product
		productdao.save(product);

	}

	/**
	 * Delete a product
	 */
	@Override
	@Transactional
	public void delete(int id) {

		// extract product
		Product product = productdao.getProduct(id);
		
		// delete the product
		productdao.delete(product);
	}

	@Override
	@Transactional
	public List<Product> getProducts() {
		
		// return list of all available products
		return productdao.getProducts();
	}

}
