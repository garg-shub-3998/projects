
package miniflipkart.service;

import java.util.List;

import miniflipkart.entity.CartItems;

/**
 * @author  Shubham Garg
 *
 */
public interface CartService {

	
	public int getCartCount(int customerid);

	
	public void addNewProduct(int pid, int customerid);

	
	public List<CartItems> getCartItems(int customerid);


	public void deleteItem(int id);


	public void deleteFromItem(int id);


	public void addToItem(int id);


	public void saveOrder(String ptype, int customerid);

	
	public void saveOrderItems(int customerid);

}
