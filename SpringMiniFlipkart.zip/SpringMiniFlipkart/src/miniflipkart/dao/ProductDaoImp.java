/**
 * 
 */
package miniflipkart.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import miniflipkart.entity.Product;

/**
 * @author Shubham Garg
 *
 */
@Repository
public class ProductDaoImp implements ProductDao {

	/**
	 * Session Factoty Object
	 */
	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * Gives the list of product of particular vendor
	 */
	@Override
	public List<Product> getProducts(int vendorid) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// create Query
		Query<Product> query = session.createQuery("from Product where vendorid = ?0");
		query.setParameter(0, vendorid);
		List<Product> products = null;

		try {
			products = query.getResultList();
		} catch (Exception e) {

		}

		return products;
	}

	/**
	 * Saves a new product into database
	 */
	@Override
	public void save(Product product) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// save product
		session.save(product);
	}

	/**
	 * Get product on the basis of id
	 */
	@Override
	public Product getProduct(int id) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// extract product
		Product product = null;
		try {
			product = session.get(Product.class, id);
		} catch (Exception e) {
			System.out.println(e);
		}
		return product;
	}

	/**
	 * delete product
	 */
	@Override
	public void delete(Product product) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// delete product
		session.delete(product);
	}

	@Override
	public List<Product> getProducts() {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// get list of products
		List<Product> p = null;
		try {
			p = session.createQuery("from Product").getResultList();
		} catch (Exception e) {
			System.out.println(e);
		}

		return p;
	}

	@Override
	public List<Product> getProductByBrandId(int id) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// create Query
		Query<Product> query = session.createQuery("from Product where brandid = ?0");
		query.setParameter(0, id);
		List<Product> products = null;
		try {
			products = query.getResultList();
		} catch (Exception e) {

		}
        System.out.println(products);
		if(products.size() == 0)return null;
		else return products;
	}

}
