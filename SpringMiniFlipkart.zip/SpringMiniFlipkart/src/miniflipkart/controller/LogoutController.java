/**
 * 
 */
package miniflipkart.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author Shubham Garg
 *
 */
@Controller
@RequestMapping("/logout")
public class LogoutController {

	/**
	 * removes user from current session
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/removeUser")
	public String removeUser(HttpServletRequest request) {
		// get the current session and invalidate it
		request.getSession().invalidate();
		return "redirect:/login/showForm";
	}
}
