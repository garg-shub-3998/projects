
package miniflipkart.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import miniflipkart.entity.Brand;
import miniflipkart.entity.Product;
import miniflipkart.entity.User;
import miniflipkart.service.BrandService;
import miniflipkart.service.ProductService;
import miniflipkart.service.UserService;
import miniflipkart.validator.Validator;

/**
 * @author Shubham Garg
 *
 */
@Controller
@RequestMapping("/vendor")
public class VendorController {
	/**
	 * User Service Object
	 */
	@Autowired
	private UserService userService;

	/**
	 * Brand Service Object
	 */
	@Autowired
	private BrandService brandService;

	/**
	 * Validator Object
	 */
	@Autowired
	private Validator validator;

	/**
	 * Product Service Object
	 */
	@Autowired
	private ProductService productService;

	/**
	 * Display the list of products of particular vendor
	 * 
	 * @param model
	 * @param request
	 * @return
	 */
	@GetMapping("/showProducts")
	public String showProducts(Model model, HttpServletRequest request) {
		// generate vendor if from session
		int vendorid = (int) request.getSession().getAttribute("userid");

		// extract list of products
		List<Product> products = productService.getProducts(vendorid);

		// adding to model
		model.addAttribute("products", products);

		return "vendor-product-list";

	}

	/**
	 * Display add new product form
	 * 
	 * @param model
	 * @return
	 */
	@GetMapping("/addProductForm")
	public String addProductForm(Model model) {
		// Extracting list of available brands
		List<Brand> brands = brandService.getBrands();

		// Adding to model
		model.addAttribute("brands", brands);

		return "add-product";

	}

	/**
	 * Adds a new product in to databse
	 * 
	 * @param product
	 * @param model
	 * @param request
	 * @param bid
	 * @return
	 */
	@PostMapping("addProduct")
	public String addProduct(@ModelAttribute Product product, Model model, HttpServletRequest request,
			@RequestParam("brandid") int bid) {

		// generating the vendor id from session
		int vendorid = (int) request.getSession().getAttribute("userid");

		// generating the brand object
		Brand brand = brandService.getBrand(bid);
		product.setBrand(brand);
		// generating the user/vendor object
		User user = userService.getUser(vendorid);
		product.setUser(user);

		// validating the new product
		boolean ans = validator.validateProduct(product, vendorid);
		if (ans) {
			// save new product
			productService.save(product);
			return "redirect:/vendor/showProducts";
		} else {
			// call add-product again with error
			model.addAttribute("errorMessage", "Product already exist");
			List<Brand> brands = brandService.getBrands();
			model.addAttribute("brands", brands);
			model.addAttribute("product", product);
			return "add-product";
		}

	}

	/**
	 * Delete product
	 * 
	 * @param id
	 * @return s
	 */
	@GetMapping("/deleteProduct")
	public String deleteBrand(@RequestParam("productid") int id,Model model) {
		System.out.println(id);
		
		if(validator.validateProductDelete(id))
		productService.delete(id);
		else
		model.addAttribute("errorMessage","Product cannot be deleted");

		
		return "redirect:/vendor/showProducts";

	}

}
