
package miniflipkart.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import miniflipkart.entity.Product;
import miniflipkart.service.CartService;
import miniflipkart.service.ProductService;

/**
 * @author Shubham Garg
 *
 */
@Controller
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private ProductService productService;

	@Autowired
	private CartService cartService;

	/**
	 * display list of products
	 * 
	 * @param model
	 * @return product-list
	 */
	@GetMapping("/showProducts")
	public String showProducts(Model model, HttpServletRequest request) {
		// Extract list of products from database
		List<Product> products = productService.getProducts();

		// get customer id from session
		int customerid = (int) request.getSession().getAttribute("userid");

		// get cart count
		int cartcount = cartService.getCartCount(customerid);

		// add addributes to the model
		model.addAttribute("products", products);
		model.addAttribute("cartcount", cartcount);

		return "customer-product-list";

	}

	@GetMapping("/addToCart")
	public String addToCart(@RequestParam("productid") int pid,  HttpServletRequest request) {

		// get customer id from session
		int customerid = (int) request.getSession().getAttribute("userid");

		cartService.addNewProduct(pid,customerid);
		return "redirect:/customer/showProducts";
	}

}
