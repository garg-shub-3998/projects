//
//package miniflipkart.tracksession;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.aspectj.lang.JoinPoint;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
//import org.aspectj.lang.annotation.Pointcut;
//import org.springframework.stereotype.Component;
//
///**
// * @author Shubham Garg
// *
// */
//@Component
//@Aspect
//public class TrackSession {
//
//	// applying pointcut on before advice
//	@Before(value = "execution(* CustomerController.*(..))")
//	public void myadvice(JoinPoint jp,HttpServletRequest request, HttpServletResponse response)// it is advice (before advice)
//	{
//		if (request.getSession().getAttribute("usertype") != null
//				&& request.getSession().getAttribute("usertype").equals("customer")) {
//			
//		} else {
//			request.getRequestDispatcher("/SpringMiniFlipkart/login/showForm").forward(request, response);
//		}
//	}
//
//	// applying pointcut on before advice
//	@Before(value = "execution(* AdminController.*(..))")
//	public void myadvice(JoinPoint jp,HttpServletRequest request, HttpServletResponse response)// it is advice (before advice)
//	{
//		if (request.getSession().getAttribute("usertype") != null
//				&& request.getSession().getAttribute("usertype").equals("admin")) {
//			
//		} else {
//			request.getRequestDispatcher("/SpringMiniFlipkart/login/showForm").forward(request, response);
//		}
//
//	}
//
//	// applying pointcut on before advice
//	@Before(value = "execution(* VendorController.*(..))")
//	public void myadvice(JoinPoint jp,HttpServletRequest request, HttpServletResponse response)// it is advice (before advice)
//	{
//		if (request.getSession().getAttribute("usertype") != null
//				&& request.getSession().getAttribute("usertype").equals("vendor")) {
//			
//		} else {
//			request.getRequestDispatcher("/SpringMiniFlipkart/login/showForm").forward(request, response);
//		}
//	}
//
//	// applying pointcut on before advice
//	@Before(value = "execution(* CartController.*(..))")
//	public void myadvice(JoinPoint jp,HttpServletRequest request, HttpServletResponse response)// it is advice (before advice)
//	{
//		if (request.getSession().getAttribute("usertype") != null
//				&& request.getSession().getAttribute("usertype").equals("customer")) {
//			
//		} else {
//			request.getRequestDispatcher("/SpringMiniFlipkart/login/showForm").forward(request, response);
//		}
//
//	}
//
//	// applying pointcut on before advice
//	@Before(value = "execution(* OrderController.*(..))")
//	public void myadvice(JoinPoint jp,HttpServletRequest request, HttpServletResponse response)// it is advice (before advice)
//	{
//
//		if (request.getSession().getAttribute("usertype") != null
//				&& request.getSession().getAttribute("usertype").equals("customer")) {
//			
//		} else {
//			request.getRequestDispatcher("/SpringMiniFlipkart/login/showForm").forward(request, response);
//		}
//	}
//
//	// applying pointcut on before advice
//	@Before(value = "execution(* LoginController.*(..))")
//	public void myadvice(JoinPoint jp,HttpServletRequest request, HttpServletResponse response)// it is advice (before advice)
//	{
//
//		if (request.getSession().getAttribute("usertype") == null) {
//		} else {
//			request.getRequestDispatcher("/SpringMiniFlipkart/logout/removeUser").forward(request,
//				response);		}
//	}
//
//}
