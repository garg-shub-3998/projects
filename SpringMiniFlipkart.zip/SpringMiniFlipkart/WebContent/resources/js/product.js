function validate(form) {
		var name = form.product.value;
		var price = form.price.value;
		var brand = form.brand.value;

		if (name == "") {
			document.getElementById("name").innerHTML = "This field is required";
			return false;
		}
		if (price == "") {
			document.getElementById("price").innerHTML = "This field is required";
			return false;
		}
		if (brand == "") {
			document.getElementById("brand").innerHTML = "This field is required";
			return false;
		}
	}