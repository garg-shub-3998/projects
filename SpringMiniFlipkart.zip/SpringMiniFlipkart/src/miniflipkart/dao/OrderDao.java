
package miniflipkart.dao;

import java.util.List;

import miniflipkart.entity.Cart;
import miniflipkart.entity.CartItems;
import miniflipkart.entity.Order;
import miniflipkart.entity.OrderItems;
import miniflipkart.entity.User;

/**
 * @author  Shubham Garg
 *
 */
public interface OrderDao {

	
	public void saveOrderItems( List<CartItems> ci, Order order );

	
	public void saveOrder(Order order);


	public Order getOrder(int customerid);


	public List<Order> getOrders(int customerid);


	public List<OrderItems> getOrderItems(int id);


	public OrderItems getOrderItemByProductId(int id);



}
