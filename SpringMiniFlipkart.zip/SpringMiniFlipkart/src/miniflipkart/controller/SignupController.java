
package miniflipkart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import miniflipkart.entity.Address;
import miniflipkart.entity.User;
import miniflipkart.service.UserService;
import miniflipkart.validator.Validator;

/**
 * @author Shubham Garg
 *
 */
@Controller
@RequestMapping("/signup")
public class SignupController {

	/**
	 * Validator Object
	 */
	@Autowired
	private Validator validator;

	/**
	 * User Service Object
	 */
	@Autowired
	private UserService userService;

	/**
	 * Display form for new user
	 * 
	 * @param model
	 * @return signup-form
	 */
	@RequestMapping("/showForm")
	public String showForm(Model model) {
		return "signup-form";
	}

	/**
	 * Add new User into database
	 * 
	 * @param user
	 * @param address
	 * @param model
	 * @return signup-form / login-form
	 */
	@PostMapping("/register")
	public String register(@ModelAttribute User user, @ModelAttribute Address address, Model model) {
		// validate for username
		boolean un = validator.validateUsername(user.getUserName());
		if (!un) {
			model.addAttribute("usernameMessage", "This username already exist");
			model.addAttribute("user", user);
			model.addAttribute("address", address);
			return "signup-form";
		}

		// validate for email
		boolean e = validator.validateEmail(user.getEmail());
		if (!e) {
			model.addAttribute("emailMessage", "This email already exist");
			model.addAttribute("user", user);
			model.addAttribute("address", address);
			return "signup-form";
		}

		// validate for phonenumber
		boolean p = validator.validatePhonenumber(user.getPhoneNumber());
		if (!p) {
			model.addAttribute("phonenumberMessage", "This phonenumber already exist");
			model.addAttribute("user", user);
			model.addAttribute("address", address);
			return "signup-form";
		}

		// save the new user
		userService.saveUser(user, address);

		model.addAttribute("Message", "Sign Up successfull");
		return "login-form";
	}
}
