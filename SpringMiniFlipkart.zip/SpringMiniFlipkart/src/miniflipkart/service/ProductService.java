
package miniflipkart.service;

import java.util.List;

import miniflipkart.entity.Product;

/**
 * @author  Shubham Garg
 *
 */
public interface ProductService {

	
	public List<Product> getProducts(int vendorid);

	
	public void save(Product product);

	
	public void delete(int id);


	public List<Product> getProducts();

}
