
package miniflipkart.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import miniflipkart.entity.Brand;

/**
 * @author Shubham Garg
 *
 */
@Repository
public class BrandDaoImp implements BrandDao {

	/**
	 * Session Factory Object
	 */
	@Autowired
	private SessionFactory sessionFacotry;

	/**
	 * Gives the list of all availabe brands from database
	 */
	@Override
	public List<Brand> getBrandList() {
		// generate session
		Session session = sessionFacotry.getCurrentSession();

		// extract brands
		List<Brand> brands = null;
		try {
			brands = session.createQuery("from Brand").getResultList();
		} catch (Exception e) {
			System.out.println(e);
		}

		return brands;
	}

	/**
	 * Save a new Brand into Database
	 */
	@Override
	public void save(Brand brand) {
		// generate session
		Session session = sessionFacotry.getCurrentSession();

		// save brand
		session.save(brand);
	}

	/**
	 * Delete Brand from database
	 */
	@Override
	public void delete(Brand brand) {
		// generate session
		Session session = sessionFacotry.getCurrentSession();

		// delete brand
		session.delete(brand);
	}

	/**
	 * Get brand by id from the database
	 */
	@Override
	public Brand getBrand(int id) {
		// generate session
		Session session = sessionFacotry.getCurrentSession();

		// extract the brand object from database
		Brand brand = null;
		try {
			brand = session.get(Brand.class, id);
		} catch (Exception e) {
			System.out.println(e);
		}
		return brand;
	}

}
