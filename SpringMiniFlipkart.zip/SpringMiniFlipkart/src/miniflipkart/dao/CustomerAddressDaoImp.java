
package miniflipkart.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import miniflipkart.entity.Address;
import miniflipkart.entity.CustomerAddress;
import miniflipkart.entity.User;

/**
 * @author Shubham Garg
 *
 */
@Repository
public class CustomerAddressDaoImp implements CustomerAddressDao {

	/**
	 * Session Factory Object
	 */
	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * Saves customer address relation
	 */
	@Override
	public void save(User user, Address address) {

		// generate session
		Session session = sessionFactory.getCurrentSession();

		// generate customeraddress object
		CustomerAddress ca = new CustomerAddress(user, address);

		// saves the object
		session.save(ca);

		System.out.println("Customer Address saved");

	}

}
