
package miniflipkart.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import miniflipkart.entity.User;

/**
 * @author Shubham Garg
 *
 */
@SuppressWarnings("rawtypes")
@Repository
public class UserDaoImp implements UserDao {

	/**
	 * SessionFactory object
	 */
	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * Gives user object from username and password
	 */
	@Override
	public User getUser(String name, String password) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// create user object
		System.out.println(name + " " + password);
		User user = null;

		try {
			// create query
			Query query = session.createQuery("from User as u where u.userName = ?0 and u.password = ?1 ");
			query.setParameter(0, name);
			query.setParameter(1, password);

			// Extract user object
			user = (User) query.uniqueResult();
			System.out.println(user);
		} catch (Exception e) {
			System.out.println(e);
		}

		return user;
	}

	/**
	 * gives user object from username
	 */
	@Override
	public User getUserByUsername(String userName) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// generate user object
		System.out.println(userName);
		User user = null;

		try {
			// create query
			Query query = session.createQuery("from User as u where u.userName = ?0");
			query.setParameter(0, userName);

			// Extract user object
			user = (User) query.uniqueResult();
			System.out.println(user);
		} catch (Exception e) {
			System.out.println(e);
		}

		return user;
	}

	/**
	 * gives user object from email
	 */
	@Override
	public User getUserByEmail(String email) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// generate user object
		System.out.println(email);
		User user = null;

		try {
			// create query
			Query query = session.createQuery("from User as u where u.email = ?0");
			query.setParameter(0, email);

			// Extract user object
			user = (User) query.uniqueResult();
			System.out.println(user);
		} catch (Exception e) {
			System.out.println(e);
		}

		return user;
	}

	/**
	 * gives user form phonenumber
	 */
	@Override
	public User getUserByPhoneNumber(String phoneNumber) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// user object
		System.out.println(phoneNumber);
		User user = null;

		try {
			// create query
			Query query = session.createQuery("from User as u where u.phoneNumber = ?0");
			query.setParameter(0, phoneNumber);

			// Extract user object
			user = (User) query.uniqueResult();
			System.out.println(user);
		} catch (Exception e) {
			System.out.println(e);
		}

		return user;
	}

	/**
	 * Saves user into database
	 */
	@Override
	public void saveUser(User user) {

		// generate session
		Session session = sessionFactory.getCurrentSession();

		// save user object
		System.out.println(user);
		session.save(user);
		System.out.println("User saved");
	}

	/**
	 * gives user by id
	 */
	@Override
	public User getUserById(int id) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// exxtract user from database
		User user = null;
		try {
			user = session.get(User.class, id);
		} catch (Exception e) {
			System.out.println(e);
		}

		return user;
	}

}
