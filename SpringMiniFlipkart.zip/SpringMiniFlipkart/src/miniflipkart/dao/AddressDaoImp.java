
package miniflipkart.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import miniflipkart.entity.Address;

/**
 * @author Shubham Garg
 *
 */
@Repository
public class AddressDaoImp implements AddressDao {

	/**
	 * Session Facotry Object
	 */
	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * Save a new Address into database
	 */
	@Override
	public void saveAddress(Address address) {

		// generate session
		Session session = sessionFactory.getCurrentSession();

		System.out.println(address);

		// save address into database
		session.save(address);

		System.out.println("Address Saved");

	}

}
