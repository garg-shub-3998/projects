
package miniflipkart.validator;

import miniflipkart.entity.Brand;
import miniflipkart.entity.Product;

/**
 * Validator Interface
 * 
 * @author  Shubham Garg
 *
 */
public interface Validator {
	
	public boolean validateLogin(String username, String password);

	
	public boolean validateUsername(String userName);

	
	public boolean validateEmail(String email);

	
	public boolean validatePhonenumber(String phoneNumber);


	public boolean validateBrand(Brand brand);


	
	public boolean validateProduct(Product product,int vendorid);


	public boolean validateProductDelete(int id);


	public boolean validateBrandDelete(int id);



}
