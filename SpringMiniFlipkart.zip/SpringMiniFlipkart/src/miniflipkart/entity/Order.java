
package miniflipkart.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

/**
 * @author Shubham Garg
 *
 */
@Entity
@Table(name = "orders")
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@ManyToOne
	@JoinColumn(name = "customerid")
	private User user;

	@Column(name = "amount")
	private int amount;
	
	@Column(name = "paymenttype")
	private String paymentType;

	@CreationTimestamp
	@Column(name = "createdat")
	private java.sql.Timestamp createdAt;

	// ---------------------------------------------
	// constructor----------------------------
	/**
	 * No-Argument Constructor
	 */
	public Order() {

	}

	/**
	 * Parameterized Constructor
	 * 
	 * @param user
	 * @param amount
	 */
	public Order(User user, int amount, String paymentType) {
		this.user = user;
		this.amount = amount;
		this.paymentType = paymentType;
	}

	// ------------------------------------ Getters/Setters
	// -----------------------------

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @return the amount
	 */
	public int getAmount() {
		return amount;
	}

	/**
	 * @return the createdAt
	 */
	public java.sql.Timestamp getCreatedAt() {
		return createdAt;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(int amount) {
		this.amount = amount;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(java.sql.Timestamp createdAt) {
		this.createdAt = createdAt;
	}
	
	

	/**
	 * @return the paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}

	/**
	 * @param paymentType the paymentType to set
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	@Override
	public String toString() {
		return String.format("Order [id=%s, user=%s, amount=%s, paymentType=%s, createdAt=%s]", id, user, amount,
				paymentType, createdAt);
	}

}
