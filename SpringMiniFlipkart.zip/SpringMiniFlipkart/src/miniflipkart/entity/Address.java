
package miniflipkart.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

/**
 * Entity class Address
 * 
 * @author Shubham Garg
 *
 */
@Entity
@Table(name = "address")
public class Address {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "housenumber")
	private String houseNumber;

	@Column(name = "locality")
	private String locality;

	@Column(name = "state")
	private String state;

	@Column(name = "country")
	private String country;

	@Column(name = "pincode")
	private String pincode;

	@CreationTimestamp
	@Column(name = "createdat")
	private java.sql.Timestamp createdAt;

	@UpdateTimestamp
	@Column(name = "updatedat")
	private java.sql.Timestamp updatedAt;

	// ------------------------------------- Constructor
	// -------------------------------------------

	// No Argument Constructor
	public Address() {

	}

	// Parameterized Constructor
	/**
	 * @param houseNumber
	 * @param locality
	 * @param state
	 * @param country
	 * @param pincode
	 * @param createdAt
	 * @param updatedAt
	 * @param user
	 */
	public Address(String houseNumber, String locality, String state, String country, String pincode) {
		this.houseNumber = houseNumber;
		this.locality = locality;
		this.state = state;
		this.country = country;
		this.pincode = pincode;
	}

	// ------------------------------------- Getters/Setters
	// -------------------------------------------

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @return the houseNumber
	 */
	public String getHouseNumber() {
		return houseNumber;
	}

	/**
	 * @return the locality
	 */
	public String getLocality() {
		return locality;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @return the pincode
	 */
	public String getPincode() {
		return pincode;
	}

	/**
	 * @return the createdAt
	 */
	public java.sql.Timestamp getCreatedAt() {
		return createdAt;
	}

	/**
	 * @return the updatedAt
	 */
	public java.sql.Timestamp getUpdatedAt() {
		return updatedAt;
	}

	/**
	 * @param set the id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @param set the houseNumber
	 */
	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}

	/**
	 * @param set the locality
	 */
	public void setLocality(String locality) {
		this.locality = locality;
	}

	/**
	 * @param set the state
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @param set the country
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @param set the pincode
	 */
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	/**
	 * @param set the createdAt
	 */
	public void setCreatedAt(java.sql.Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @param set the updatedAt
	 */
	public void setUpdatedAt(java.sql.Timestamp updatedAt) {
		this.updatedAt = updatedAt;
	}

	@Override
	public String toString() {
		return String.format(
				"Address [id=%s, houseNumber=%s, locality=%s, state=%s, country=%s, pincode=%s, createdAt=%s, updatedAt=%s]",
				id, houseNumber, locality, state, country, pincode, createdAt, updatedAt);
	}

}
