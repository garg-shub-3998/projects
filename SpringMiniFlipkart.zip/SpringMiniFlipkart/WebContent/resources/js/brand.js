function confirm() {
		alert("Are you sure you want to delete");
		return true;
	}