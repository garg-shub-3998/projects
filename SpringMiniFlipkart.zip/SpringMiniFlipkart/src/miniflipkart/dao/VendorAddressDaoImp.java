
package miniflipkart.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import miniflipkart.entity.Address;
import miniflipkart.entity.User;
import miniflipkart.entity.VendorAddress;

/**
 * @author Shubham Garg
 *
 */
@Repository
public class VendorAddressDaoImp implements VendorAddressDao {

	/**
	 * Session Factory Oject
	 */
	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * Function save to save vendoraddress in dataase
	 */
	@Override
	public void save(User user, Address address) {

		// generate session
		Session session = sessionFactory.getCurrentSession();

		// generate vendoraddress
		VendorAddress va = new VendorAddress(user, address);

		// save vendoraddress
		session.save(va);

		System.out.println("Vendor Address saved");

	}
}
