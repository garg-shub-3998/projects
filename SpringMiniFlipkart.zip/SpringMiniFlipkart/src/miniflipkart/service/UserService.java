
 
package miniflipkart.service;

import miniflipkart.entity.Address;
import miniflipkart.entity.User;

/**
 * @author  Shubham Garg
 *
 */
public interface UserService {

	public void saveUser(User user, Address address);

	public String getUserType(String username, String password);

	public int getUserId(String username, String password);

	
	public User getUser(int vendorid);

}
