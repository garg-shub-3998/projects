
package miniflipkart.dao;

import java.util.List;

import miniflipkart.entity.Product;

/**
 * @author  Shubham Garg
 *
 */
public interface ProductDao {

	
	public List<Product> getProducts(int vendorid);

	
	public void save(Product product);

	
	public Product getProduct(int id);

	
	public void delete(Product product);


	public List<Product> getProducts();


	public List<Product> getProductByBrandId(int id);

}
