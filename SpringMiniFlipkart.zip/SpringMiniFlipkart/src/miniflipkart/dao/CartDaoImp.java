/**
 * 
 */
package miniflipkart.dao;

import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import miniflipkart.entity.Cart;
import miniflipkart.entity.CartItems;
import miniflipkart.entity.Product;
import miniflipkart.entity.User;

/**
 * @author Shubham Garg
 *
 */
@Repository
public class CartDaoImp implements CartDao {

	/**
	 * Session Factory Object
	 */
	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * Generate cart for new Customer
	 */
	@Override
	public void generateCart(User user) {
		// generate new cart object
		Cart cart = new Cart(0, 0, user);

		// generate session
		Session session = sessionFactory.getCurrentSession();

		// save the cart
		session.save(cart);

	}

	@Override
	public Cart getCart(int customerid) {
		// generate session
		Session session = sessionFactory.getCurrentSession();

		// get cart
		Query query = session.createQuery("from Cart where customerid = ?0 ");
		query.setParameter(0, customerid);
		Cart cart = null;
		try {
			cart = (Cart) query.getSingleResult();
		} catch (Exception e) {
			System.out.println(e);
		}

		return cart;
	}

	@Override
	public List<CartItems> getCartItems(int cartid) {
		// create session
		Session session = sessionFactory.getCurrentSession();

		// get cartitems list
		Query query = session.createQuery("from CartItems where cartid = ?0");
		query.setParameter(0, cartid);
		List<CartItems> ci = null;
		try {
			ci = query.getResultList();
		} catch (Exception e) {
			System.out.println(e);
		}
		return ci;
	}

	@Override
	public void addNewCartItem(Product product, Cart cart) {
		// create session
		Session session = sessionFactory.getCurrentSession();

		// create cartitem object
		CartItems ci = new CartItems(cart, product, product.getPrice(), 1, product.getPrice());

		// save cart item
		session.save(ci);

	}

	@Override
	public void saveCart(Cart cart) {
		// create session
		Session session = sessionFactory.getCurrentSession();

		// save or update cart
		session.saveOrUpdate(cart);

	}

	@Override
	public CartItems getCartItem(int id) {
		// create session
		Session session = sessionFactory.getCurrentSession();

		// generate cartitem
		CartItems ci = null;
		try {
			ci = session.get(CartItems.class, id);
		} catch (Exception e) {
			System.out.println(e);
		}
		return ci;
	}

	@Override
	public void deleteCartItem(CartItems ci) {
		// create session
		Session session = sessionFactory.getCurrentSession();

		// delete cartitem
		session.delete(ci);
	}

	@Override
	public void saveCartItem(CartItems ci) {
		// create session
		Session session = sessionFactory.getCurrentSession();

		// save or update cart
		session.saveOrUpdate(ci);

	}

	@Override
	public CartItems getCartItem(Cart cart, Product product) {
		// create session
		Session session = sessionFactory.getCurrentSession();

		// get cartitems list
		Query query = session.createQuery("from CartItems where cartid = ?0 and productid = ?1");
		query.setParameter(0, cart.getId());
		query.setParameter(1, product.getId());

		CartItems ci = null;

		try {
			ci = (CartItems) query.getSingleResult();
		} catch (Exception e) {
			System.out.println(e);
		}

		return ci;
	}

	@Override
	public CartItems getCartItemByProductId(int id) {
		// create session
		Session session = sessionFactory.getCurrentSession();

		// get cartitems list
		Query<CartItems> query = session.createQuery("from CartItems where productid = ?0");
		query.setParameter(0, id);

		List<CartItems> ci = null;

		try {
			ci = query.getResultList();
		} catch (Exception e) {
			System.out.println(e);
		}

		if(ci.size() == 0) return null;
		else return ci.get(0);
	}

}
