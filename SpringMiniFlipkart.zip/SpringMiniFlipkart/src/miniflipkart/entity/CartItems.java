
package miniflipkart.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

/**
 * @author Shubham Garg
 *
 */
@Entity
@Table(name = "cartitems")
public class CartItems {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "cartid")
	private Cart cart;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "productid")
	private Product product;

	@Column(name = "unitprice")
	private int unitPrice;

	@Column(name = "quantity")
	private int quantity;

	@Column(name = "totalprice")
	private int totalPrice;

	@CreationTimestamp
	@Column(name = "createdat")
	private java.sql.Timestamp createdAt;

	@UpdateTimestamp
	@Column(name = "updatedat")
	private java.sql.Timestamp updateddAt;

	// Constructor

	/**
	 * No-Argument Constructor
	 */
	public CartItems() {

	}

	/**
	 * Parameterized Constructor
	 * 
	 * @param cart
	 * @param product
	 * @param unitPrice
	 * @param quantity
	 * @param totalPrice
	 */
	public CartItems(Cart cart, Product product, int unitPrice, int quantity, int totalPrice) {
		this.cart = cart;
		this.product = product;
		this.unitPrice = unitPrice;
		this.quantity = quantity;
		this.totalPrice = totalPrice;
	}

	// Getters and Setters

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @return the cart
	 */
	public Cart getCart() {
		return cart;
	}

	/**
	 * @return the product
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 * @return the unitPrice
	 */
	public int getUnitPrice() {
		return unitPrice;
	}

	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @return the totalPrice
	 */
	public int getTotalPrice() {
		return totalPrice;
	}

	/**
	 * @return the createdAt
	 */
	public java.sql.Timestamp getCreatedAt() {
		return createdAt;
	}

	/**
	 * @return the updateddAt
	 */
	public java.sql.Timestamp getUpdateddAt() {
		return updateddAt;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @param cart the cart to set
	 */
	public void setCart(Cart cart) {
		this.cart = cart;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

	/**
	 * @param unitPrice the unitPrice to set
	 */
	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/**
	 * @param totalPrice the totalPrice to set
	 */
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(java.sql.Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @param updateddAt the updateddAt to set
	 */
	public void setUpdateddAt(java.sql.Timestamp updateddAt) {
		this.updateddAt = updateddAt;
	}

	@Override
	public String toString() {
		return String.format(
				"CartItems [id=%s, cart=%s, product=%s, unitPrice=%s, quantity=%s, totalPrice=%s, createdAt=%s, updateddAt=%s]",
				id, cart, product, unitPrice, quantity, totalPrice, createdAt, updateddAt);
	}

}
