
package miniflipkart.dao;

import miniflipkart.entity.Address;
import miniflipkart.entity.User;

/**
 * @author  Shubham Garg
 *
 */
public interface VendorAddressDao {

	
	public void save(User user, Address address);

}
